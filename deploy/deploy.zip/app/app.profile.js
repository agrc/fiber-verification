//>>built
profile={resourceTags:{test:function(){return!1},copyOnly:function(a,b){return/^app\/resources\//.test(b)&&!/\.css$/.test(a)},amd:function(a,b){return!this.copyOnly(a,b)&&/\.js$/.test(a)},miniExclude:function(a,b){return b in{"app/package":1,"app/tests/jasmineTestBootstrap":1}}}};
//# sourceMappingURL=app.profile.js.map
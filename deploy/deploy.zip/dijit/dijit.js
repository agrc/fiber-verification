//>>built
define("dijit/dijit","./main ./_base dojo/parser ./_Widget ./_TemplatedMixin ./_Container ./layout/_LayoutWidget ./form/_FormWidget ./form/_FormValueWidget".split(" "),function(a){return a});
//# sourceMappingURL=dijit.js.map
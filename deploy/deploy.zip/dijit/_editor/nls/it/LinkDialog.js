//>>built
define("dijit/_editor/nls/it/LinkDialog",{createLinkTitle:"Propriet\u00e0 collegamento",insertImageTitle:"Propriet\u00e0 immagine",url:"URL:",text:"Descrizione:",target:"Destinazione:",set:"Imposta",currentWindow:"Finestra corrente",parentWindow:"Finestra padre",topWindow:"Finestra superiore",newWindow:"Nuova finestra"});
//# sourceMappingURL=LinkDialog.js.map
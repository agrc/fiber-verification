//>>built
define("dijit/_editor/nls/tr/FontChoice",{fontSize:"Boyut",fontName:"Yaz\u0131 Tipi",formatBlock:"Bi\u00e7im",serif:"serif","sans-serif":"sans-serif",monospace:"tek aral\u0131kl\u0131",cursive:"el yaz\u0131s\u0131",fantasy:"fantazi",noFormat:"Yok",p:"Paragraf",h1:"Ba\u015fl\u0131k",h2:"Alt Ba\u015fl\u0131k",h3:"Alt Alt Ba\u015fl\u0131k",pre:"\u00d6nceden Bi\u00e7imlendirilmi\u015f",1:"xx-k\u00fc\u00e7\u00fck",2:"x-k\u00fc\u00e7\u00fck",3:"k\u00fc\u00e7\u00fck",4:"orta",5:"b\u00fcy\u00fck",6:"x-b\u00fcy\u00fck",
7:"xx-b\u00fcy\u00fck"});
//# sourceMappingURL=FontChoice.js.map
//>>built
define("dijit/_editor/nls/pt/LinkDialog",{createLinkTitle:"Propriedades de Link",insertImageTitle:"Propriedades de Imagem",url:"URL:",text:"Descri\u00e7\u00e3o:",target:"Destino:",set:"Configurar",currentWindow:"Janela Atual",parentWindow:"Janela Pai",topWindow:"Primeira Janela",newWindow:"Nova Janela"});
//# sourceMappingURL=LinkDialog.js.map
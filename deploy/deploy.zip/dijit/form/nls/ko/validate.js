//>>built
define("dijit/form/nls/ko/validate",{invalidMessage:"\uc785\ub825\ub41c \uac12\uc774 \uc62c\ubc14\ub974\uc9c0 \uc54a\uc2b5\ub2c8\ub2e4.",missingMessage:"\uc774 \uac12\uc740 \ud544\uc218\uc785\ub2c8\ub2e4.",rangeMessage:"\uc774 \uac12\uc740 \ubc94\uc704\ub97c \ubc97\uc5b4\ub0a9\ub2c8\ub2e4."});
//# sourceMappingURL=validate.js.map
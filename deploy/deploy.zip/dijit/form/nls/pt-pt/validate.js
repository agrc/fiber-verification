//>>built
define("dijit/form/nls/pt-pt/validate",{invalidMessage:"O valor introduzido n\u00e3o \u00e9 v\u00e1lido.",missingMessage:"Este valor \u00e9 requerido.",rangeMessage:"Este valor encontra-se fora do intervalo."});
//# sourceMappingURL=validate.js.map
//>>built
define("dijit/form/nls/tr/Textarea",{iframeEditTitle:"d\u00fczenleme alan\u0131",iframeFocusTitle:"d\u00fczenleme alan\u0131 \u00e7er\u00e7evesi"});
//# sourceMappingURL=Textarea.js.map
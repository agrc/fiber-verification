//>>built
define("dijit/nls/pl/loading",{loadingState:"\u0141adowanie...",errorState:"Niestety, wyst\u0105pi\u0142 b\u0142\u0105d"});
//# sourceMappingURL=loading.js.map
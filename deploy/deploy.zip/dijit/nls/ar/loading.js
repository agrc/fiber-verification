//>>built
define("dijit/nls/ar/loading",{loadingState:"\u062c\u0627\u0631\u064a \u0627\u0644\u062a\u062d\u0645\u064a\u0644...",errorState:"\u0639\u0641\u0648\u0627\u060c \u062d\u062f\u062b \u062e\u0637\u0623"});
//# sourceMappingURL=loading.js.map
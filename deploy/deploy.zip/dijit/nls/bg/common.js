//>>built
define("dijit/nls/bg/common",{buttonOk:"\u041e\u041a",buttonCancel:"\u041e\u0442\u043c\u0435\u043d\u0438",buttonSave:"\u0417\u0430\u043f\u0430\u0437\u0438",itemClose:"\u0417\u0430\u0442\u0432\u043e\u0440\u0438"});
//# sourceMappingURL=common.js.map
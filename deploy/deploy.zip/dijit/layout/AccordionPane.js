//>>built
define("dijit/layout/AccordionPane",["dojo/_base/declare","dojo/_base/kernel","./ContentPane"],function(a,b,c){return a("dijit.layout.AccordionPane",c,{constructor:function(){b.deprecated("dijit.layout.AccordionPane deprecated, use ContentPane instead","","2.0")},onSelected:function(){}})});
//# sourceMappingURL=AccordionPane.js.map
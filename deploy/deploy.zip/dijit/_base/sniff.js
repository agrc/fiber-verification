//>>built
define("dijit/_base/sniff",["dojo/uacss"],function(){});
//# sourceMappingURL=sniff.js.map
//>>built
define("agrc/modules/String",[],function(){return{replaceAll:function(a,b,c){return a.split(b).join(c)},removeWhiteSpace:function(a){return a.replace(/\s/g,"")},toProperCase:function(a){return a.replace(/\w\S*/g,function(a){return a.charAt(0).toUpperCase()+a.substr(1).toLowerCase()})},endsWith:function(a,b){return-1!==a.indexOf(b,a.length-b.length)}}});
//# sourceMappingURL=String.js.map
//>>built
define("agrc/widgets/map/ThemeInfo",["dojo/_base/declare","dojo/_base/lang"],function(a,b){return a([],{label:"",layers:null,constructor:function(a){this.layers=[];b.mixin(this,a)}})});
//# sourceMappingURL=ThemeInfo.js.map